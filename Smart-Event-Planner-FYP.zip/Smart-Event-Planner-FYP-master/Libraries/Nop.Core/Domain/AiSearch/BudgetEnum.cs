﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Core.Domain.AiSearch
{
    public enum BudgetEnum
    {
        Budget_60_40 = 1,
        Budget_50_50 = 2,
        Budget_40_60 = 3
    }
}
